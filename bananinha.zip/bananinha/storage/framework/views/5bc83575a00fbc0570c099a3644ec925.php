<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listagem de alunos</title>
    <a href="<?php echo e(route('aluno.create')); ?>">Cadastrar</a>
</head>
<body>
<table border="1">
    <tr>
        <th>Id</th>
        <th>Nome</th>
        <th>Data nascimento</th>
        <th>Email</th>
        <th>CPF</th>
        <th>Telefone</th>
    </tr>
    <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->id); ?></td>
        <td><?php echo e($item->nome); ?></td>
        <td><?php echo e($item->data); ?></td>
        <td><?php echo e($item->email); ?></td>
        <td><?php echo e($item->cpf); ?></td>
        <td><?php echo e($item->telefone); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
<?php /**PATH C:\laragon\www\bananinha\resources\views/aluno/list.blade.php ENDPATH**/ ?>