<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulário aluno</title>
</head>
<body>
<form action="<?php echo e(route('aluno.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
<label for="">Nome</label><br>
<input type="text" name="nome"><br><br>
<label for="">Data de nascimento</label><br>
<input type="text" name="data"><br><br>
<label for="">CPF</label><br>
<input type="text" name="cpf"><br><br>
<label for="">Email</label><br>
<input type="email" name="email"><br><br>
<label for="">Telefone</label><br>
<input type="text" name="telefone"><br><br>

<button type="submit">Salvar</button>
<a href="<?php echo e(route('aluno.index')); ?>">Voltar</a>
</form>
</body>
</html>
<?php /**PATH C:\laragon\www\bananinha\resources\views/aluno/form.blade.php ENDPATH**/ ?>